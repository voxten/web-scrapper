import functools

from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash

from flaskr.db import get_db

bp = Blueprint('auth', __name__, url_prefix='/auth')

@bp.route('/register', methods=('GET', 'POST'))
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        is_admin = request.form.get('is_admin') == 'on'
        db = get_db()
        error = None

        if not username:
            error = 'Username is required.'
        elif not password:
            error = 'Password is required.'

        if error is None:
            try:
                db.execute(
                    "INSERT INTO user (username, password, is_admin) VALUES (?, ? , ?)",
                    (username, generate_password_hash(password),is_admin),
                )
                db.commit()
            except db.IntegrityError:
                error = f"User {username} is already registered."
            else:
                return redirect(url_for("auth.login"))

        flash(error)

    return render_template('auth/register.html')

@bp.route('/login', methods=('GET', 'POST'))
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        error = None
        user = db.execute(
            'SELECT * FROM user WHERE username = ?', (username,)
        ).fetchone()

        if user is None:
            error = 'Incorrect username.'
        elif not check_password_hash(user['password'], password):
            error = 'Incorrect password.'

        if error is None:
            session.clear()
            session['user_id'] = user['id']
            return redirect(url_for('index'))

        flash(error)

    return render_template('auth/login.html')

@bp.before_app_request
def load_logged_in_user():
    user_id = session.get('user_id')

    if user_id is None:
        g.user = None
    else:
        g.user = get_db().execute(
            'SELECT * FROM user WHERE id = ?', (user_id,)
        ).fetchone()

@bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            return redirect(url_for('auth.login'))

        return view(**kwargs)

    return wrapped_view


@bp.route('/delete_user/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    db = get_db()
    error = None

    # Sprawdź, czy użytkownik jest zalogowany i ma uprawnienia do usuwania użytkowników (jeśli potrzebne)

    # Pobierz informacje o użytkowniku, który ma zostać usunięty
    user = db.execute('SELECT * FROM user WHERE id = ?', (user_id,)).fetchone()

    if user is None:
        error = 'User not found.'
    else:
        try:
            # Usuń użytkownika z bazy danych
            db.execute('DELETE FROM user WHERE id = ?', (user_id,))
            db.commit()
        except Exception as e:
            # W przypadku niepowodzenia usuwania użytkownika, ustaw odpowiedni błąd
            error = f"Failed to delete user: {e}"

    if error:
        flash(error)

    # Przekieruj użytkownika na stronę, która ma być wyświetlana po usunięciu użytkownika
    return redirect(url_for('blog.users'))